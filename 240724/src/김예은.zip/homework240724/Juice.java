package homework240724;

public class Juice extends Drink {

	public Juice(String name, int price) {

		super(name, price);
	}

}
