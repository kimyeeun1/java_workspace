package homework240724;

public class Consumer {
	
	private int age;
	private int alcoholGauge;
	
	public Consumer (int age, int alcoholGauge) {
		
		this.age = age;
		this.alcoholGauge = alcoholGauge;
		
	}
	
	public int getAge() {
		
		return this.age;
		
	}
	
	public int getAlcoholGauge() {
		
		return this.alcoholGauge;
		
	}
	
}
